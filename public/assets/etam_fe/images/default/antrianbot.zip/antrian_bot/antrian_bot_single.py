#!/usr/bin/env python3
"""
Antrian Bot - Single File Version
Web Queue Automation with reCAPTCHA v2 Support
Compatible with: Windows PC & Android (Termux)

Requirements: pip install selenium requests

Usage:
    python antrian_bot_single.py
    python antrian_bot_single.py --headless
    python antrian_bot_single.py -c custom_config.json
"""

import json
import time
import random
import sys
import os
import re
import logging
import argparse
import requests
from datetime import datetime

try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait, Select
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.chrome.service import Service
    from selenium.common.exceptions import (
        TimeoutException, 
        NoSuchElementException,
        ElementClickInterceptedException,
        StaleElementReferenceException
    )
except ImportError:
    print("ERROR: Selenium not installed. Run: pip install selenium requests")
    sys.exit(1)


# ============================================================================
# DEFAULT CONFIG (used if config.json not found)
# ============================================================================
DEFAULT_CONFIG = {
    "target_url": "https://example.com/antrian",
    "captcha_service": {
        "provider": "2captcha",
        "api_key": "YOUR_2CAPTCHA_API_KEY",
        "enabled": False
    },
    "settings": {
        "headless": False,
        "random_delay_min": 2,
        "random_delay_max": 5,
        "max_retries": 3,
        "retry_delay": 10,
        "timeout": 30,
        "ban_wait_time": 300
    },
    "users": [
        {"username": "user1@email.com", "password": "password1", "enabled": True}
    ],
    "target_locations": [
        {"name": "Lokasi A", "selector_value": "lokasi_a", "preferred_time": "08:00", "enabled": True}
    ]
}


# ============================================================================
# LOGGER UTILITY
# ============================================================================
class AntrianLogger:
    def __init__(self, log_dir="logs"):
        self.log_dir = log_dir
        self.stats = {
            "total_attempts": 0,
            "successful": 0,
            "failed": 0,
            "details": []
        }
        
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        log_filename = datetime.now().strftime("%Y%m%d_%H%M%S") + "_antrian.log"
        log_path = os.path.join(log_dir, log_filename)
        
        self.logger = logging.getLogger("AntrianBot")
        self.logger.setLevel(logging.DEBUG)
        
        if not self.logger.handlers:
            fh = logging.FileHandler(log_path, encoding="utf-8")
            fh.setLevel(logging.DEBUG)
            
            ch = logging.StreamHandler()
            ch.setLevel(logging.INFO)
            
            formatter = logging.Formatter(
                "%(asctime)s | %(levelname)-8s | %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S"
            )
            fh.setFormatter(formatter)
            ch.setFormatter(formatter)
            
            self.logger.addHandler(fh)
            self.logger.addHandler(ch)
    
    def info(self, message):
        self.logger.info(message)
    
    def error(self, message):
        self.logger.error(message)
    
    def warning(self, message):
        self.logger.warning(message)
    
    def debug(self, message):
        self.logger.debug(message)
    
    def success(self, message):
        self.logger.info(f"[SUCCESS] {message}")
    
    def record_attempt(self, user, location, time_slot, success, queue_number=None, error=None):
        self.stats["total_attempts"] += 1
        
        detail = {
            "timestamp": datetime.now().isoformat(),
            "user": user,
            "location": location,
            "time_slot": time_slot,
            "success": success,
            "queue_number": queue_number,
            "error": error
        }
        self.stats["details"].append(detail)
        
        if success:
            self.stats["successful"] += 1
            self.success(f"User: {user} | Lokasi: {location} | Jam: {time_slot} | No. Antrian: {queue_number}")
        else:
            self.stats["failed"] += 1
            self.error(f"User: {user} | Lokasi: {location} | Error: {error}")
    
    def print_summary(self):
        self.info("=" * 60)
        self.info("SUMMARY HASIL REGISTRASI ANTRIAN")
        self.info("=" * 60)
        self.info(f"Total Percobaan  : {self.stats['total_attempts']}")
        self.info(f"Berhasil         : {self.stats['successful']}")
        self.info(f"Gagal            : {self.stats['failed']}")
        
        if self.stats['total_attempts'] > 0:
            success_rate = (self.stats['successful'] / self.stats['total_attempts']) * 100
            self.info(f"Success Rate     : {success_rate:.1f}%")
        
        self.info("=" * 60)
        
        if self.stats["successful"] > 0:
            self.info("DAFTAR BERHASIL:")
            for d in self.stats["details"]:
                if d["success"]:
                    self.info(f"  - {d['user']} @ {d['location']} | Jam: {d['time_slot']} | No: {d['queue_number']}")
        
        if self.stats["failed"] > 0:
            self.info("DAFTAR GAGAL:")
            for d in self.stats["details"]:
                if not d["success"]:
                    self.info(f"  - {d['user']} @ {d['location']} | Error: {d['error']}")
        
        self.info("=" * 60)
        return self.stats


# ============================================================================
# CAPTCHA SOLVER
# ============================================================================
class CaptchaSolver:
    def __init__(self, config):
        self.provider = config.get("provider", "manual")
        self.api_key = config.get("api_key", "")
        self.enabled = config.get("enabled", False)
    
    def solve_recaptcha_v2(self, site_key, page_url, logger=None):
        if not self.enabled or not self.api_key:
            return self._manual_solve(logger)
        
        if self.provider == "2captcha":
            return self._solve_2captcha(site_key, page_url, logger)
        elif self.provider == "anti-captcha":
            return self._solve_anticaptcha(site_key, page_url, logger)
        else:
            return self._manual_solve(logger)
    
    def _solve_2captcha(self, site_key, page_url, logger=None):
        try:
            if logger:
                logger.info("Sending captcha to 2captcha...")
            
            submit_url = "http://2captcha.com/in.php"
            params = {
                "key": self.api_key,
                "method": "userrecaptcha",
                "googlekey": site_key,
                "pageurl": page_url,
                "json": 1
            }
            
            response = requests.post(submit_url, data=params, timeout=30)
            result = response.json()
            
            if result.get("status") != 1:
                if logger:
                    logger.error(f"2captcha submit error: {result.get('request')}")
                return None
            
            captcha_id = result.get("request")
            if logger:
                logger.info(f"Captcha submitted, ID: {captcha_id}")
            
            result_url = "http://2captcha.com/res.php"
            params = {
                "key": self.api_key,
                "action": "get",
                "id": captcha_id,
                "json": 1
            }
            
            for attempt in range(30):
                time.sleep(5)
                response = requests.get(result_url, params=params, timeout=30)
                result = response.json()
                
                if result.get("status") == 1:
                    if logger:
                        logger.info("Captcha solved successfully!")
                    return result.get("request")
                elif result.get("request") == "CAPCHA_NOT_READY":
                    if logger:
                        logger.info(f"Waiting for captcha solution... ({attempt + 1}/30)")
                else:
                    if logger:
                        logger.error(f"2captcha error: {result.get('request')}")
                    return None
            
            if logger:
                logger.error("Captcha solving timeout")
            return None
            
        except Exception as e:
            if logger:
                logger.error(f"2captcha exception: {str(e)}")
            return None
    
    def _solve_anticaptcha(self, site_key, page_url, logger=None):
        try:
            if logger:
                logger.info("Sending captcha to anti-captcha...")
            
            create_url = "https://api.anti-captcha.com/createTask"
            payload = {
                "clientKey": self.api_key,
                "task": {
                    "type": "RecaptchaV2TaskProxyless",
                    "websiteURL": page_url,
                    "websiteKey": site_key
                }
            }
            
            response = requests.post(create_url, json=payload, timeout=30)
            result = response.json()
            
            if result.get("errorId") != 0:
                if logger:
                    logger.error(f"Anti-captcha error: {result.get('errorDescription')}")
                return None
            
            task_id = result.get("taskId")
            if logger:
                logger.info(f"Task created, ID: {task_id}")
            
            result_url = "https://api.anti-captcha.com/getTaskResult"
            payload = {"clientKey": self.api_key, "taskId": task_id}
            
            for attempt in range(30):
                time.sleep(5)
                response = requests.post(result_url, json=payload, timeout=30)
                result = response.json()
                
                if result.get("status") == "ready":
                    if logger:
                        logger.info("Captcha solved successfully!")
                    return result.get("solution", {}).get("gRecaptchaResponse")
                elif result.get("status") == "processing":
                    if logger:
                        logger.info(f"Waiting for solution... ({attempt + 1}/30)")
                else:
                    if logger:
                        logger.error(f"Anti-captcha error: {result.get('errorDescription')}")
                    return None
            
            if logger:
                logger.error("Captcha solving timeout")
            return None
            
        except Exception as e:
            if logger:
                logger.error(f"Anti-captcha exception: {str(e)}")
            return None
    
    def _manual_solve(self, logger=None):
        if logger:
            logger.info("=" * 50)
            logger.info("MANUAL CAPTCHA REQUIRED!")
            logger.info("Please solve the captcha in the browser window")
            logger.info("=" * 50)
        
        input("\n>>> Press ENTER after solving the captcha manually... ")
        return "MANUAL_SOLVED"


def get_recaptcha_site_key(driver):
    try:
        iframes = driver.find_elements("tag name", "iframe")
        for iframe in iframes:
            src = iframe.get_attribute("src") or ""
            if "recaptcha" in src and "k=" in src:
                match = re.search(r'k=([^&]+)', src)
                if match:
                    return match.group(1)
        
        recaptcha_div = driver.find_elements("css selector", "[data-sitekey]")
        if recaptcha_div:
            return recaptcha_div[0].get_attribute("data-sitekey")
        
        g_recaptcha = driver.find_elements("css selector", ".g-recaptcha")
        if g_recaptcha:
            return g_recaptcha[0].get_attribute("data-sitekey")
        
        return None
    except Exception:
        return None


def inject_captcha_token(driver, token):
    try:
        script = f"""
        document.getElementById('g-recaptcha-response').innerHTML = '{token}';
        if (typeof grecaptcha !== 'undefined') {{
            var callback = document.querySelector('[data-callback]');
            if (callback) {{
                var callbackName = callback.getAttribute('data-callback');
                if (window[callbackName]) {{
                    window[callbackName]('{token}');
                }}
            }}
        }}
        """
        driver.execute_script(script)
        return True
    except Exception:
        return False


# ============================================================================
# MAIN BOT CLASS
# ============================================================================
class AntrianBot:
    def __init__(self, config_path="config.json"):
        self.config = self._load_config(config_path)
        self.logger = AntrianLogger()
        self.captcha_solver = CaptchaSolver(self.config.get("captcha_service", {}))
        self.driver = None
        self.settings = self.config.get("settings", {})
        
    def _load_config(self, config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"Config file not found: {config_path}")
            print("Creating default config.json...")
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(DEFAULT_CONFIG, f, indent=4)
            print(f"Please edit {config_path} with your settings and run again.")
            sys.exit(0)
        except json.JSONDecodeError as e:
            print(f"ERROR: Invalid JSON in config: {e}")
            sys.exit(1)
    
    def _random_delay(self, min_sec=None, max_sec=None):
        min_sec = min_sec or self.settings.get("random_delay_min", 2)
        max_sec = max_sec or self.settings.get("random_delay_max", 5)
        delay = random.uniform(min_sec, max_sec)
        self.logger.debug(f"Waiting {delay:.1f} seconds...")
        time.sleep(delay)
    
    def _init_driver(self):
        options = Options()
        
        if self.settings.get("headless", False):
            options.add_argument("--headless")
        
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--disable-infobars")
        options.add_argument("--start-maximized")
        options.add_argument("--disable-extensions")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-gpu")
        options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option("useAutomationExtension", False)
        
        try:
            self.driver = webdriver.Chrome(options=options)
            self.driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
                "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
            })
            self.driver.implicitly_wait(10)
            self.logger.info("WebDriver initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize WebDriver: {e}")
            self.logger.info("Make sure ChromeDriver is installed and in PATH")
            sys.exit(1)
    
    def _wait_for_element(self, by, value, timeout=None, clickable=False):
        timeout = timeout or self.settings.get("timeout", 30)
        try:
            if clickable:
                element = WebDriverWait(self.driver, timeout).until(
                    EC.element_to_be_clickable((by, value))
                )
            else:
                element = WebDriverWait(self.driver, timeout).until(
                    EC.presence_of_element_located((by, value))
                )
            return element
        except TimeoutException:
            return None
    
    def _safe_click(self, element, retries=3):
        for i in range(retries):
            try:
                element.click()
                return True
            except (ElementClickInterceptedException, StaleElementReferenceException):
                self._random_delay(0.5, 1)
                try:
                    self.driver.execute_script("arguments[0].click();", element)
                    return True
                except:
                    continue
        return False
    
    def _check_banned(self):
        page_source = self.driver.page_source.lower()
        ban_indicators = ["banned", "blocked", "too many requests", "rate limit", "silakan tunggu"]
        return any(indicator in page_source for indicator in ban_indicators)
    
    def _check_logged_out(self):
        current_url = self.driver.current_url.lower()
        return "login" in current_url or "auth" in current_url
    
    def login(self, username, password):
        self.logger.info(f"Attempting login for: {username}")
        
        try:
            self.driver.get(self.config["target_url"])
            self._random_delay()
            
            username_field = self._wait_for_element(By.CSS_SELECTOR, "input[name='username'], input[name='email'], input[type='email'], #username, #email")
            password_field = self._wait_for_element(By.CSS_SELECTOR, "input[name='password'], input[type='password'], #password")
            
            if not username_field or not password_field:
                self.logger.error("Login form not found")
                return False
            
            username_field.clear()
            for char in username:
                username_field.send_keys(char)
                time.sleep(random.uniform(0.05, 0.15))
            
            self._random_delay(0.5, 1)
            
            password_field.clear()
            for char in password:
                password_field.send_keys(char)
                time.sleep(random.uniform(0.05, 0.15))
            
            self._random_delay()
            
            site_key = get_recaptcha_site_key(self.driver)
            if site_key:
                self.logger.info("reCAPTCHA detected on login page")
                token = self.captcha_solver.solve_recaptcha_v2(site_key, self.driver.current_url, self.logger)
                if not token:
                    self.logger.error("Failed to solve captcha")
                    return False
            
            login_btn = self._wait_for_element(
                By.CSS_SELECTOR, 
                "button[type='submit'], input[type='submit'], .btn-login, #login-btn",
                clickable=True
            )
            
            if login_btn:
                self._safe_click(login_btn)
                self._random_delay(3, 5)
            else:
                self.logger.error("Login button not found")
                return False
            
            if self._check_logged_out():
                self.logger.error("Login failed - still on login page")
                return False
            
            self.logger.info("Login successful!")
            return True
            
        except Exception as e:
            self.logger.error(f"Login error: {str(e)}")
            return False
    
    def navigate_to_antrian(self):
        self.logger.info("Navigating to antrian menu...")
        
        try:
            self._random_delay()
            
            antrian_menu = self._wait_for_element(
                By.XPATH,
                "//a[contains(text(), 'Antrian')] | //a[contains(@href, 'antrian')] | //button[contains(text(), 'Antrian')]",
                clickable=True
            )
            
            if antrian_menu:
                self._safe_click(antrian_menu)
                self._random_delay()
                self.logger.info("Navigated to antrian page")
                return True
            else:
                self.logger.error("Antrian menu not found")
                return False
                
        except Exception as e:
            self.logger.error(f"Navigation error: {str(e)}")
            return False
    
    def select_location(self, location_value, location_name):
        self.logger.info(f"Selecting location: {location_name}")
        
        try:
            self._random_delay()
            
            selectors = [
                f"//option[@value='{location_value}']",
                f"//select/option[contains(text(), '{location_name}')]",
                f"//div[contains(@class, 'location')]//input[@value='{location_value}']",
                f"//label[contains(text(), '{location_name}')]",
                f"//button[contains(text(), '{location_name}')]",
                f"//div[contains(text(), '{location_name}')]"
            ]
            
            for selector in selectors:
                try:
                    element = self._wait_for_element(By.XPATH, selector, timeout=5, clickable=True)
                    if element:
                        if element.tag_name == "option":
                            select_element = element.find_element(By.XPATH, "..")
                            Select(select_element).select_by_value(location_value)
                        else:
                            self._safe_click(element)
                        
                        self._random_delay()
                        self.logger.info(f"Location selected: {location_name}")
                        return True
                except:
                    continue
            
            self.logger.error(f"Location not found: {location_name}")
            return False
            
        except Exception as e:
            self.logger.error(f"Location selection error: {str(e)}")
            return False
    
    def click_submit(self):
        self.logger.info("Clicking submit...")
        
        try:
            self._random_delay()
            
            submit_btn = self._wait_for_element(
                By.CSS_SELECTOR,
                "button[type='submit'], input[type='submit'], .btn-submit, #submit-btn, .btn-primary",
                clickable=True
            )
            
            if submit_btn:
                self._safe_click(submit_btn)
                self._random_delay()
                return True
            else:
                self.logger.error("Submit button not found")
                return False
                
        except Exception as e:
            self.logger.error(f"Submit error: {str(e)}")
            return False
    
    def select_time_slot(self, preferred_time):
        self.logger.info(f"Selecting time slot (preferred: {preferred_time})...")
        
        try:
            self._random_delay()
            
            time_slots = self.driver.find_elements(
                By.CSS_SELECTOR, 
                ".time-slot, .jam-antrian, input[name='time'], button[data-time], .slot-available"
            )
            
            if not time_slots:
                time_slots = self.driver.find_elements(
                    By.XPATH,
                    "//button[contains(@class, 'time')] | //div[contains(@class, 'slot')] | //label[contains(@class, 'time')]"
                )
            
            if not time_slots:
                self.logger.warning("No time slots found, looking for alternatives...")
                time_select = self._wait_for_element(By.CSS_SELECTOR, "select[name*='time'], select[name*='jam']", timeout=5)
                if time_select:
                    Select(time_select).select_by_index(1)
                    return True
            
            selected = False
            for slot in time_slots:
                slot_text = slot.text or slot.get_attribute("value") or slot.get_attribute("data-time") or ""
                
                if preferred_time in slot_text:
                    if self._safe_click(slot):
                        self.logger.info(f"Selected preferred time: {slot_text}")
                        selected = True
                        break
            
            if not selected and time_slots:
                for slot in time_slots:
                    if slot.is_enabled():
                        if self._safe_click(slot):
                            slot_text = slot.text or slot.get_attribute("value") or "Unknown"
                            self.logger.info(f"Selected available time: {slot_text}")
                            selected = True
                            break
            
            if selected:
                self._random_delay()
                return True
            else:
                self.logger.error("No available time slots")
                return False
                
        except Exception as e:
            self.logger.error(f"Time selection error: {str(e)}")
            return False
    
    def handle_final_captcha_and_submit(self):
        self.logger.info("Handling final submission...")
        
        try:
            self._random_delay()
            
            site_key = get_recaptcha_site_key(self.driver)
            if site_key:
                self.logger.info("reCAPTCHA detected on submission page")
                token = self.captcha_solver.solve_recaptcha_v2(site_key, self.driver.current_url, self.logger)
                if not token:
                    self.logger.error("Failed to solve final captcha")
                    return None
            
            if not self.click_submit():
                return None
            
            self._random_delay(3, 5)
            
            return self._extract_queue_number()
            
        except Exception as e:
            self.logger.error(f"Final submission error: {str(e)}")
            return None
    
    def _extract_queue_number(self):
        try:
            selectors = [
                ".queue-number", ".nomor-antrian", "#queue-result",
                ".modal-body h2", ".modal-body .number",
                "//div[contains(@class, 'modal')]//strong",
                "//div[contains(@class, 'success')]//span"
            ]
            
            for selector in selectors:
                try:
                    if selector.startswith("//"):
                        element = self._wait_for_element(By.XPATH, selector, timeout=5)
                    else:
                        element = self._wait_for_element(By.CSS_SELECTOR, selector, timeout=5)
                    
                    if element and element.text:
                        numbers = re.findall(r'\d+', element.text)
                        if numbers:
                            return numbers[0]
                except:
                    continue
            
            page_source = self.driver.page_source
            patterns = [r'nomor[:\s]*(\d+)', r'antrian[:\s]*(\d+)', r'queue[:\s]*(\d+)', r'no[:\s]*(\d+)']
            for pattern in patterns:
                match = re.search(pattern, page_source, re.IGNORECASE)
                if match:
                    return match.group(1)
            
            return "UNKNOWN"
            
        except Exception as e:
            self.logger.error(f"Queue extraction error: {str(e)}")
            return "UNKNOWN"
    
    def process_registration(self, user, location):
        username = user["username"]
        password = user["password"]
        location_name = location["name"]
        location_value = location["selector_value"]
        preferred_time = location.get("preferred_time", "08:00")
        
        self.logger.info("=" * 60)
        self.logger.info(f"Processing: {username} -> {location_name}")
        self.logger.info("=" * 60)
        
        max_retries = self.settings.get("max_retries", 3)
        retry_delay = self.settings.get("retry_delay", 10)
        
        for attempt in range(max_retries):
            try:
                if self._check_banned():
                    ban_wait = self.settings.get("ban_wait_time", 300)
                    self.logger.warning(f"Detected ban! Waiting {ban_wait} seconds...")
                    time.sleep(ban_wait)
                    self._init_driver()
                
                if not self.login(username, password):
                    raise Exception("Login failed")
                
                if not self.navigate_to_antrian():
                    raise Exception("Navigation failed")
                
                if not self.select_location(location_value, location_name):
                    raise Exception("Location selection failed")
                
                if not self.click_submit():
                    raise Exception("Location submit failed")
                
                if not self.select_time_slot(preferred_time):
                    raise Exception("Time selection failed")
                
                queue_number = self.handle_final_captcha_and_submit()
                
                if queue_number:
                    self.logger.record_attempt(username, location_name, preferred_time, success=True, queue_number=queue_number)
                    return True
                else:
                    raise Exception("Failed to get queue number")
                    
            except Exception as e:
                self.logger.warning(f"Attempt {attempt + 1}/{max_retries} failed: {str(e)}")
                
                if attempt < max_retries - 1:
                    self.logger.info(f"Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                    
                    if self.driver:
                        try:
                            self.driver.delete_all_cookies()
                        except:
                            pass
                else:
                    self.logger.record_attempt(username, location_name, preferred_time, success=False, error=str(e))
        
        return False
    
    def run(self):
        self.logger.info("=" * 60)
        self.logger.info("ANTRIAN BOT STARTED")
        self.logger.info(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.logger.info("=" * 60)
        
        users = [u for u in self.config.get("users", []) if u.get("enabled", True)]
        locations = [l for l in self.config.get("target_locations", []) if l.get("enabled", True)]
        
        if not users:
            self.logger.error("No enabled users in config")
            return
        
        if not locations:
            self.logger.error("No enabled locations in config")
            return
        
        self.logger.info(f"Users to process: {len(users)}")
        self.logger.info(f"Locations to process: {len(locations)}")
        
        self._init_driver()
        
        try:
            for user in users:
                for location in locations:
                    self.process_registration(user, location)
                    self._random_delay(5, 10)
                    
        except KeyboardInterrupt:
            self.logger.warning("Bot stopped by user (Ctrl+C)")
        except Exception as e:
            self.logger.error(f"Unexpected error: {str(e)}")
        finally:
            if self.driver:
                self.driver.quit()
            
            self.logger.print_summary()


# ============================================================================
# ENTRY POINT
# ============================================================================
def main():
    print("""
    ╔══════════════════════════════════════════════════════════╗
    ║           ANTRIAN BOT - Single File Version              ║
    ║      Web Queue Automation with reCAPTCHA v2 Support      ║
    ║      Compatible: Windows PC & Android (Termux)           ║
    ╚══════════════════════════════════════════════════════════╝
    """)
    
    parser = argparse.ArgumentParser(description="Antrian Bot - Web Queue Automation")
    parser.add_argument("-c", "--config", default="config.json", help="Config file path")
    parser.add_argument("--headless", action="store_true", help="Run in headless mode")
    args = parser.parse_args()
    
    bot = AntrianBot(args.config)
    
    if args.headless:
        bot.settings["headless"] = True
    
    bot.run()


if __name__ == "__main__":
    main()