"""
Captcha Solver Module
Supports: 2captcha, anti-captcha, or manual solving
"""

import time
import requests


class CaptchaSolver:
    def __init__(self, config):
        self.provider = config.get("provider", "manual")
        self.api_key = config.get("api_key", "")
        self.enabled = config.get("enabled", False)
    
    def solve_recaptcha_v2(self, site_key, page_url, logger=None):
        """
        Solve Google reCAPTCHA v2
        Returns: g-recaptcha-response token or None
        """
        if not self.enabled or not self.api_key:
            return self._manual_solve(logger)
        
        if self.provider == "2captcha":
            return self._solve_2captcha(site_key, page_url, logger)
        elif self.provider == "anti-captcha":
            return self._solve_anticaptcha(site_key, page_url, logger)
        else:
            return self._manual_solve(logger)
    
    def _solve_2captcha(self, site_key, page_url, logger=None):
        """Solve using 2captcha.com API"""
        try:
            if logger:
                logger.info("Sending captcha to 2captcha...")
            
            submit_url = "http://2captcha.com/in.php"
            params = {
                "key": self.api_key,
                "method": "userrecaptcha",
                "googlekey": site_key,
                "pageurl": page_url,
                "json": 1
            }
            
            response = requests.post(submit_url, data=params, timeout=30)
            result = response.json()
            
            if result.get("status") != 1:
                if logger:
                    logger.error(f"2captcha submit error: {result.get('request')}")
                return None
            
            captcha_id = result.get("request")
            if logger:
                logger.info(f"Captcha submitted, ID: {captcha_id}")
            
            result_url = "http://2captcha.com/res.php"
            params = {
                "key": self.api_key,
                "action": "get",
                "id": captcha_id,
                "json": 1
            }
            
            max_attempts = 30
            for attempt in range(max_attempts):
                time.sleep(5)
                response = requests.get(result_url, params=params, timeout=30)
                result = response.json()
                
                if result.get("status") == 1:
                    token = result.get("request")
                    if logger:
                        logger.info("Captcha solved successfully!")
                    return token
                elif result.get("request") == "CAPCHA_NOT_READY":
                    if logger:
                        logger.info(f"Waiting for captcha solution... ({attempt + 1}/{max_attempts})")
                    continue
                else:
                    if logger:
                        logger.error(f"2captcha error: {result.get('request')}")
                    return None
            
            if logger:
                logger.error("Captcha solving timeout")
            return None
            
        except Exception as e:
            if logger:
                logger.error(f"2captcha exception: {str(e)}")
            return None
    
    def _solve_anticaptcha(self, site_key, page_url, logger=None):
        """Solve using anti-captcha.com API"""
        try:
            if logger:
                logger.info("Sending captcha to anti-captcha...")
            
            create_url = "https://api.anti-captcha.com/createTask"
            payload = {
                "clientKey": self.api_key,
                "task": {
                    "type": "RecaptchaV2TaskProxyless",
                    "websiteURL": page_url,
                    "websiteKey": site_key
                }
            }
            
            response = requests.post(create_url, json=payload, timeout=30)
            result = response.json()
            
            if result.get("errorId") != 0:
                if logger:
                    logger.error(f"Anti-captcha error: {result.get('errorDescription')}")
                return None
            
            task_id = result.get("taskId")
            if logger:
                logger.info(f"Task created, ID: {task_id}")
            
            result_url = "https://api.anti-captcha.com/getTaskResult"
            payload = {
                "clientKey": self.api_key,
                "taskId": task_id
            }
            
            max_attempts = 30
            for attempt in range(max_attempts):
                time.sleep(5)
                response = requests.post(result_url, json=payload, timeout=30)
                result = response.json()
                
                if result.get("status") == "ready":
                    token = result.get("solution", {}).get("gRecaptchaResponse")
                    if logger:
                        logger.info("Captcha solved successfully!")
                    return token
                elif result.get("status") == "processing":
                    if logger:
                        logger.info(f"Waiting for solution... ({attempt + 1}/{max_attempts})")
                    continue
                else:
                    if logger:
                        logger.error(f"Anti-captcha error: {result.get('errorDescription')}")
                    return None
            
            if logger:
                logger.error("Captcha solving timeout")
            return None
            
        except Exception as e:
            if logger:
                logger.error(f"Anti-captcha exception: {str(e)}")
            return None
    
    def _manual_solve(self, logger=None):
        """Manual captcha solving - pause for user input"""
        if logger:
            logger.info("=" * 50)
            logger.info("MANUAL CAPTCHA REQUIRED!")
            logger.info("Please solve the captcha in the browser window")
            logger.info("=" * 50)
        
        input("\n>>> Press ENTER after solving the captcha manually... ")
        return "MANUAL_SOLVED"


def get_recaptcha_site_key(driver):
    """Extract reCAPTCHA site key from page"""
    try:
        iframes = driver.find_elements("tag name", "iframe")
        for iframe in iframes:
            src = iframe.get_attribute("src") or ""
            if "recaptcha" in src and "k=" in src:
                import re
                match = re.search(r'k=([^&]+)', src)
                if match:
                    return match.group(1)
        
        recaptcha_div = driver.find_elements("css selector", "[data-sitekey]")
        if recaptcha_div:
            return recaptcha_div[0].get_attribute("data-sitekey")
        
        g_recaptcha = driver.find_elements("css selector", ".g-recaptcha")
        if g_recaptcha:
            return g_recaptcha[0].get_attribute("data-sitekey")
        
        return None
    except Exception:
        return None


def inject_captcha_token(driver, token):
    """Inject solved captcha token into the page"""
    try:
        script = f"""
        document.getElementById('g-recaptcha-response').innerHTML = '{token}';
        if (typeof grecaptcha !== 'undefined') {{
            var callback = document.querySelector('[data-callback]');
            if (callback) {{
                var callbackName = callback.getAttribute('data-callback');
                if (window[callbackName]) {{
                    window[callbackName]('{token}');
                }}
            }}
        }}
        """
        driver.execute_script(script)
        return True
    except Exception:
        return False