"""
Logger Utility - Tracking hasil registrasi antrian
"""

import logging
import os
from datetime import datetime


class AntrianLogger:
    def __init__(self, log_dir="logs"):
        self.log_dir = log_dir
        self.stats = {
            "total_attempts": 0,
            "successful": 0,
            "failed": 0,
            "details": []
        }
        
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        log_filename = datetime.now().strftime("%Y%m%d_%H%M%S") + "_antrian.log"
        log_path = os.path.join(log_dir, log_filename)
        
        self.logger = logging.getLogger("AntrianBot")
        self.logger.setLevel(logging.DEBUG)
        
        fh = logging.FileHandler(log_path, encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)
        
        self.logger.addHandler(fh)
        self.logger.addHandler(ch)
    
    def info(self, message):
        self.logger.info(message)
    
    def error(self, message):
        self.logger.error(message)
    
    def warning(self, message):
        self.logger.warning(message)
    
    def debug(self, message):
        self.logger.debug(message)
    
    def success(self, message):
        self.logger.info(f"[SUCCESS] {message}")
    
    def record_attempt(self, user, location, time_slot, success, queue_number=None, error=None):
        """Record registration attempt"""
        self.stats["total_attempts"] += 1
        
        detail = {
            "timestamp": datetime.now().isoformat(),
            "user": user,
            "location": location,
            "time_slot": time_slot,
            "success": success,
            "queue_number": queue_number,
            "error": error
        }
        self.stats["details"].append(detail)
        
        if success:
            self.stats["successful"] += 1
            self.success(f"User: {user} | Lokasi: {location} | Jam: {time_slot} | No. Antrian: {queue_number}")
        else:
            self.stats["failed"] += 1
            self.error(f"User: {user} | Lokasi: {location} | Error: {error}")
    
    def print_summary(self):
        """Print final summary"""
        self.info("=" * 60)
        self.info("SUMMARY HASIL REGISTRASI ANTRIAN")
        self.info("=" * 60)
        self.info(f"Total Percobaan  : {self.stats['total_attempts']}")
        self.info(f"Berhasil         : {self.stats['successful']}")
        self.info(f"Gagal            : {self.stats['failed']}")
        
        if self.stats['total_attempts'] > 0:
            success_rate = (self.stats['successful'] / self.stats['total_attempts']) * 100
            self.info(f"Success Rate     : {success_rate:.1f}%")
        
        self.info("=" * 60)
        
        if self.stats["successful"] > 0:
            self.info("DAFTAR BERHASIL:")
            for d in self.stats["details"]:
                if d["success"]:
                    self.info(f"  - {d['user']} @ {d['location']} | Jam: {d['time_slot']} | No: {d['queue_number']}")
        
        if self.stats["failed"] > 0:
            self.info("DAFTAR GAGAL:")
            for d in self.stats["details"]:
                if not d["success"]:
                    self.info(f"  - {d['user']} @ {d['location']} | Error: {d['error']}")
        
        self.info("=" * 60)
        return self.stats
    
    def get_stats(self):
        return self.stats