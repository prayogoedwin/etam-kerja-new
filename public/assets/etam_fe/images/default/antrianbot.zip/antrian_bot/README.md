# Antrian Bot

Web queue automation script with Google reCAPTCHA v2 support.

## Installation

### Windows
```bash
pip install -r requirements.txt
```

### Android (Termux)
```bash
pkg update
pkg install python chromium
pip install selenium requests
```

## Configuration

Edit `config.json`:

```json
{
    "target_url": "https://your-target-website.com/login",
    "captcha_service": {
        "provider": "2captcha",
        "api_key": "YOUR_API_KEY",
        "enabled": false
    },
    "settings": {
        "headless": false,
        "random_delay_min": 2,
        "random_delay_max": 5,
        "max_retries": 3,
        "ban_wait_time": 300
    },
    "users": [
        {
            "username": "user@email.com",
            "password": "password",
            "enabled": true
        }
    ],
    "target_locations": [
        {
            "name": "Lokasi A",
            "selector_value": "lokasi_a",
            "preferred_time": "08:00",
            "enabled": true
        }
    ]
}
```

## Usage

```bash
# Normal mode (with browser visible)
python bot.py

# Headless mode (no browser window)
python bot.py --headless

# Custom config file
python bot.py -c my_config.json
```

## Captcha Options

1. **Manual (default)**: Bot pauses, you solve captcha manually in browser
2. **2captcha**: Set `enabled: true` and add API key (~$3/1000 solves)
3. **anti-captcha**: Alternative service

## Important Notes

1. **Update Selectors**: Edit `bot.py` selectors to match your target website
2. **Anti-Detection**: Random delays built-in to avoid ban
3. **Rate Limiting**: If banned, bot waits `ban_wait_time` seconds
4. **Logs**: Check `logs/` folder for detailed history

## Customization

Search for `NOTE: Update` comments in `bot.py` to find selectors that need adjustment based on actual website structure.

## Troubleshooting

- **ChromeDriver error**: Install matching ChromeDriver for your Chrome version
- **Element not found**: Update CSS selectors in bot.py
- **Login fails**: Check credentials and captcha handling